from Funcionario import Funcionario

class Administrador(Funcionario):

    __slots__ = []

    def __init__(self):
        super().__init__()


